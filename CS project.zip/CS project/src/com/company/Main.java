package com.company;

import javax.swing.*;

public class Main extends JFrame {

    Main(){
        //size and location
        setBounds(0,0,5500,3667);


        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/adb.jpg"));
        JLabel L1= new JLabel(i1);

        L1.setBounds(0,0,500,367);
        add(L1);
        setLayout(null);
        setVisible(true);
    }
    public static void main(String[] args) {

        //initial blank frame call
        new Main();
    }
}
