package com.company;

import javax.swing.*;

public class Main extends JFrame {

    Main(){
        
        //size and location
        setBounds(0,0,1366,768);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/adb.jpg"));
        JLabel L1= new JLabel(i1);

        L1.setBounds(0,0,1366,768);
        add(L1);
        setLayout(null);
        setVisible(true);
    }
    public static void main(String[] args) {

        //front page
        new Main();
    }
}